defmodule HrBrandAgentWeb.Layouts do
  use HrBrandAgentWeb, :html

  embed_templates "layouts/*"
end
